public class App1 {

    public static void main(String[] args) {
        System.out.println("Hola mundo");
        int x=10,y=20;
        int promedio;
        promedio = (x + y)/2;
        System.out.println("El promedio es:" + promedio);
    }

}
