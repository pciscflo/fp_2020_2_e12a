public class AppKahoot1 {
    public static void main(String[] args) {
        double numero1 = 5;
        double numero2 = 10;
        double resultado = numero1 / numero2 * 40;
        System.out.println(resultado);
    }
}
