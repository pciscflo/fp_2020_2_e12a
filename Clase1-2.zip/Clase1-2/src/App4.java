public class App4 {
    public static void main(String[] args) {
        int x = 5;
        int y = 5;
        int z;
        z = x*y/6;//5.5=25/6=4.16 ==>4  ok   10(5/6)=8.333 ==>8 se descarta
        System.out.println(z);
    }
}
