public class App6 {
    public static void main(String[] args) {
        double radio = 4;
        double area;
        area = Math.PI*Math.pow(radio,2);
        System.out.println("Area:" + area);
    }
}
